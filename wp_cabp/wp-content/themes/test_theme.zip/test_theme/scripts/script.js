window.onscroll = () => {
  const nav = document.querySelector('#site-navigation');
  if(this.scrollY <= 10){
    nav.classList.remove("nav-black");
    nav.classList.add("main-navigation");
    nav.classList.add("nav-bar");
  }  else{
    nav.classList.add("main-navigation");
    nav.classList.add("nav-bar");
    nav.classList.add("nav-black");
  };
};